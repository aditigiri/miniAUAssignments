package com.au2018.EmployeeDataForum;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main( String[] args ){
        
    	ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeDao dao=(EmployeeDao) appContext.getBean("edao");
        List<Employee> list=dao.getAllEmployeesRowMapper();
        for(Employee e:list)
            System.out.println(e.getName()); 

        List<Employee> empList = new ArrayList<Employee>();
        Employee e1= new Employee(1,"Aditi",50000);
        Employee e2= new Employee(2,"Sita",60000);
        Employee e3= new Employee(3,"Gita",90000);
        Employee e4= new Employee(4,"Ram",35000);
        Employee e5= new Employee(5,"Sam",32000);
        Employee e6= new Employee(6,"David",23000);
        Employee e7= new Employee(7,"Simon",10000);
        Employee e8= new Employee(8,"Mercy",13000);
        Employee e9= new Employee(9,"Preeti",69000);
        Employee e10= new Employee(10,"Pintu",37000);
        
        empList.add(e1);
        empList.add(e2);
        empList.add(e3);
        empList.add(e4);
        empList.add(e5);
        empList.add(e6);
        empList.add(e7);
        empList.add(e8);
        empList.add(e3);
        empList.add(e9);
        empList.add(e10);
        dao.insertBatch(empList);

    }
}